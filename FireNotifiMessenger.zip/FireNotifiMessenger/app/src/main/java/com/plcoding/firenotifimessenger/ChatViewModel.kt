package com.plcoding.firenotifimessenger

import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.ktx.messaging
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.create
import java.io.IOException

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    var state by mutableStateOf(ChatState())
        private set

    private val api: FcmApi = Retrofit.Builder()
        .baseUrl("http://192.168.0.106:8080/")  // Dirección IP del host
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create()

    init {
        viewModelScope.launch {
            try {
                Firebase.messaging.subscribeToTopic("chat").await()
                Toast.makeText(getApplication(), "Tema Aplicado con exito.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(getApplication(), "Error al aplicar el tema: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun onRemoteTokenChange(newToken: String) {
        state = state.copy(remoteToken = newToken)
        Toast.makeText(getApplication(), "Token actualizado: $newToken", Toast.LENGTH_SHORT).show()
    }

    fun onSubmitRemoteToken() {
        if (state.remoteToken.isNotEmpty()) {
            state = state.copy(isEnteringToken = false)
            Toast.makeText(getApplication(), "Token enviado con éxito", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(getApplication(), "Token no puede estar vacío", Toast.LENGTH_SHORT).show()
        }
    }

    fun onMessageChange(message: String) {
        state = state.copy(messageText = message)
    }

    fun sendMessage(isBroadcast: Boolean) {
        if (state.messageText.isEmpty()) {
            Toast.makeText(getApplication(), "Mensaje no puede estar vacío", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            val messageDto = SendMessageDto(
                to = if (isBroadcast) null else state.remoteToken,
                notification = NotificationBody(
                    title = "New message!",
                    body = state.messageText
                )
            )

            try {
                if (isBroadcast) {
                    Toast.makeText(getApplication(), "Enviando mensaje broadcast", Toast.LENGTH_SHORT).show()
                    api.broadcast(messageDto)
                } else {
                    Toast.makeText(getApplication(), "Enviando mensaje a token: ${state.remoteToken}", Toast.LENGTH_SHORT).show()
                    api.sendMessage(messageDto)
                }

                state = state.copy(messageText = "")
                Toast.makeText(getApplication(), "Mensaje enviado", Toast.LENGTH_SHORT).show()
            } catch (e: HttpException) {
                e.printStackTrace()
                Toast.makeText(getApplication(), "Error HTTP: ${e.message}", Toast.LENGTH_SHORT).show()
            } catch (e: IOException) {
                e.printStackTrace()
                Toast.makeText(getApplication(), "Error IO: ${e.message}", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(getApplication(), "Error desconocido: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
